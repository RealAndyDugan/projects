Andy Dugan
William Gavins
Thriambak Giriprakash
Ani Manjunath
Damandeep Riat

Instructions for running:
Double click index.html or home.html to view the landing page of the prototype.